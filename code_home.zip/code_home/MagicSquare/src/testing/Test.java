package testing;

import java.util.Scanner;

/**
 * Created by bbk on 2/18/17.
 */
public class Test {
    public static void main(String[] args) {
        int[][] arr= new int[100][100];
        int[] a=new int[100];
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the value in array:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                arr[i][j] = input.nextInt();
            }
        }
        int b=0;

        while (b<9) {
            for (int i = 0; i < 3; i++) {

                for (int j = 0; j < 3; j++) {
                    a[b] = arr[i][j];
                    b++;
                }
            }
        }
        System.out.println("  2d array ");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(arr[i][j]);
            }
            System.out.println("\n");
        }
        System.out.println("array ");
        for (int i = 0; i < 9; i++) {
            System.out.print(a[i]);
        }
        for (int i = 0; i < a.length-1; i++) {

            for (int j = 0; j < a.length-1; j++) {

                if (a[i]==a[j]){
                    System.out.println("Equal found");
                }
            }

        }
    }
}

