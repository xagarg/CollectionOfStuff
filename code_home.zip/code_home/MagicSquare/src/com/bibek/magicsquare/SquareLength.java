package com.bibek.magicsquare;

/**
 * Created by bbk on 2/17/17.
 */
public class SquareLength {

    private int length;

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }


}
