package com.bibek.magicsquare;

public class Main {

    public static void main(String[] args) {

        MagicSquareFunction magicSquareFunction=new MagicSquareFunction();

        magicSquareFunction.getSquareLength();


        magicSquareFunction.startFunction();


    }
}
