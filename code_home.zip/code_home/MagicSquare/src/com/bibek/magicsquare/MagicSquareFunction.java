package com.bibek.magicsquare;

import java.util.*;

/**
 * Created by bbk on 2/17/17.
 */
public class MagicSquareFunction {

    SquareLength squareLength = new SquareLength();
    int[][] squareArray = new int[100][100];
    Scanner input = new Scanner(System.in);



    public void getSquareLength() {

        System.out.println("Enter the length of :");
        int length = input.nextInt();
        squareLength.setLength(length);
    }

    public void startFunction() {

        int le = squareLength.getLength();
        boolean result = false;


        for (int i = 0; i < le; i++) {
            for (int j = 0; j < le; j++) {
                squareArray[i][j] = input.nextInt();
            }
            System.out.print("\n");
        }

        System.out.print("Enter Solution for square with " + le + " length :\n");
        for (int i = 0; i < le; i++) {
            for (int j = 0; j < le; j++) {
                System.out.print(squareArray[i][j] + " ");
            }
            System.out.print("\n");
        }


        int answer = le * (le * le + 1) / 2;

        int sumDiagonal = 0;

        for (int i = 0; i < le; i++) {
            int sumRow = 0;

            //int sumColumn = 0;


            for (int j = 0; j < le; j++)  {
                sumRow += squareArray[i][j];

                if (i == j) {
                    sumDiagonal += squareArray[i][j];
                }
            }

            System.out.println("The row sum "+i+1 +" "+sumRow);
            System.out.println("The disgonal sum "+sumDiagonal);
            System.out.println("The answer "+answer);

            if (sumRow == answer) {
                result = true;
            } else {
                result = false;
            }
        }

        for (int i = 0; i < le; i++){
            for (int j = 0; j < le; j++){
                if(squareArray[i][j]==1){

                }
            }
        }

        if (result==true){
            System.out.println("Congratulation your answer is correct!!!");
        }else {
            System.out.println("Try Again!!!!!");
        }
    }


    public boolean checkingElement(int[][] arr){
        boolean re=false;
        int[] a=new int[10000];
        int b=0;
        int le = squareLength.getLength();
        while (b<le*le) {
            for (int i = 0; i < le; i++) {

                for (int j = 0; j < le; j++) {
                    a[b] = arr[i][j];
                    b++;
                }
            }
        }

        for (int i = 0; i < a.length-1; i++) {

            for (int j = i+1; j < a.length-1; j++) {
                if (a[i]!=a[j]){
                    re=false;
                }
            }
        }

        return re;
    }
}




