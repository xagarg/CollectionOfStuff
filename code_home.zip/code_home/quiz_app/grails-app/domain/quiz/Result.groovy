package quiz

class Result {

    String question
    String clickedAns
    String correctAns
    int marks

    static constraints = {

    }
}
