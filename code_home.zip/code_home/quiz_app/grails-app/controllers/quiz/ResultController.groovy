package quiz

class ResultController {
    def resultDisplay(){}
}
