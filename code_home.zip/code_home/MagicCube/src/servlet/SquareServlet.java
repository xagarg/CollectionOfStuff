package servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

/**
 * Created by bbk on 2/20/17.
 */
public class SquareServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //int[][] values= new int[100][100];

        int selectedItem=0;
        selectedItem= Integer.parseInt(request.getParameter("length"));
        String[] pa=new String[1000];
               pa = request.getParameterValues("tr");

        Map<String, String[]> s =request.getParameterMap();
      //  Map map = request.getParameterMap();
        System.out.println("Map size :"+s.size());
        System.out.println("Map object :"+s);
            System.out.println("from td"+pa);

       // String length=request.getParameter("length");
        System.out.println("The length is :"+selectedItem);
        request.getRequestDispatcher("/index.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
