package operation;

/**
 * Created by bbk on 2/16/17.
 */
public class CubeFunction {
}
