package operation;

/**
 * Created by bbk on 2/16/17.
 */
public class Cube {

    private int cubeNumber;

    public int getCubeNumber() {
        return cubeNumber;
    }

    public void setCubeNumber(int cubeNumber) {
        this.cubeNumber = cubeNumber;
    }
}
